<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	$ut = $_SESSION['userType'];
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	} else if( $ut== '2') {
		header("Location: home.php");
		exit;
	}
	// select loggedin users detail
$ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);

    if( isset($_POST['btn-paid']) ) {
    $ema = trim($_POST['email']);    
    mysqli_query($dbc, "DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc, "INSERT INTO to_receive(userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package) SELECT userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package FROM user_table WHERE email='$ema'");
        unset($ema);  
    
    }

	if( isset($_POST['btn-del']) ) {
        $email = trim($_POST['email']);    
    mysqli_query($dbc, "DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc, "DELETE FROM user_table WHERE email='$ema'");
        unset($email);  
    }



?>
<?php include('menu.php'); ?>
 

<div id="main" style="padding-left:40px;margin-left:250px;">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; menu</span>
   
    <form>
    <label> Search Member</label>
    <input type="text"></input>    
    
    <input type="submit"> 
    </form>
    <br/>
    <br/>

    <div class="container">
                    <div  class="span9 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
                        <table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
                            <thead>
                                <tr><th>S.No</th><th>From</th><th>Mes</th><th>Img</th><th><div class='noPrint'>action</div></th></tr>
                            </thead>
            	          <?php
                            $query=mysqli_query($dbc,"SELECT * FROM msg");
                            $i= 1;
                            while ($row = mysqli_fetch_array($query)) {
                                $paidto[$i] =  $row['email'];                               
                                $user1[$i]= $row['mes']; 
                                $img[$i]= $row['img']; 
                               
                            ?>
                            <tr>
                                
                                <td><?php echo $i;?></td>
                                <td><?php echo $paidto[$i];?></td>
                                <td><?php echo $user1[$i];?></td>
                                <td> <img src="uploads/<?php echo $img[$i];?> "  height="180" width="242"></td>
                                <td>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
                                <div class="form-group">
                                <?php $email[$i] =  $row['email']; ?>  
                                <input type="hidden" name="email" value="<?php echo $email[$i]; ?>" />
                                <button type="submit" class="btn btn-block btn-primary" name="btn-">Enlarge Image</button>
                                <button type="submit" class="btn btn-block btn-primary" name="btn-paid">Mark as Paid</button>
                                <button type="submit" class="btn btn-block btn-primary" name="btn-del">Delete User</button>
                                </div>
                                
                            </form>
                                </td>
  
                            </tr>
            
                            <?php $i= $i+1; } ?>
                            <?php $i= 0; ?>
                            </table>	
                    </div>
                </div>
    </div>
 
    </body>

</html>
<?php ob_end_flush(); ?>