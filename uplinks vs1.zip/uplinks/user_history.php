<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);

    if( isset($_POST['btn-paid']) ) {
    $ema = trim($_POST['email']);    
    mysqli_query($dbc,"DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc,"INSERT INTO to_receive(userName,firstName,lastName,phoneNo,accName,accNo,email,bankName) SELECT userName,firstName,lastName,phoneNo,accName,accNo,email,bankName FROM user_table WHERE email='$ema'");
        unset($ema);  
    
    }
	if( isset($_POST['btn-purge']) ) {
        $email = trim($_POST['email']);    
    mysqli_query($dbc,"UPDATE pending SET topurge='1' WHERE email='$email'"); 
        unset($email);  
    }
        
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userName']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="assets/css/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap-responsive.css" type="text/css"  />   
    <link rel="stylesheet" href="assets/css/bootstrap-responsive.min.css" type="text/css"  />
    
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="fiji_tourism_logo_detail.gif" rel="shortcut icon" type="image/vnd.microsoft.icon">

<!-- Google Fonts -->
<link href="css/css_003.css" rel="stylesheet" type="text/css">
<link href="css/css_004.css" rel="stylesheet" type="text/css">
<link href="css/css_002.css" rel="stylesheet" type="text/css">
        <!-- base css -->
        <link rel="stylesheet" href="css/base.css" />
</head>
<body>
            
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="home.php">Home</a>
  <a href="editprofile.php">Edit Profile</a>
  <a href="user_history.php">Payment History</a>
  <a href="contact.php">Contact Admin</a>
  <a href="logout.php?logout">Logout</a>
</div>
        
        

<div id="main" style="padding-left:40px;">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; menu</span>
    <br/>

    <div class="container">
                    <div  class="span9 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
                        <table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
                            <thead>
                                <tr><th>S.No</th><th>Paid To</th><th>First Donor</th><th>Second Donor</th><th>Merge ID</th><th>Date</th></tr>
                            </thead>
            	          <?php
                            $me= $userRow['email'];
                            $query=mysqli_query($dbc,"SELECT * FROM history WHERE torec='$me' OR topay1='$me' OR topay2='$me'");
                            $i= 1;
                            while ($row = mysqli_fetch_array($query)) {
                                $paidto[$i] =  $row['torec'];                               
                                $user1[$i]= $row['topay1']; 
                                $user2[$i]= $row['topay2']; 
                                $added[$i]= $row['added']; 
                                $mergeID[$i]= $row['mergeID']; 
                              
                            ?>
                            <tr>
                                
                                <td><?php echo $i;?></td>
                                <td><?php echo $paidto[$i];?></td>
                                <td><?php echo $user1[$i];?></td>
                                <td><?php echo $user2[$i];?></td>                                
                                <td><?php echo $mergeID[$i];?></td> 
                                <td><?php echo $added[$i];?></td>
                            </tr>
            
                            <?php $i= $i+1; } ?>
                            <?php $i= 0; ?>
                            </table>	
                    </div>
                </div>
    </div>

    </body>
</html>
<?php ob_end_flush(); ?>