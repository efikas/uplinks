


<footer style="text-align: center;">
    <p> Copyrights 2017. Uplinks International. All Rights Reserved.<a target="_blank" href="http://pebblesdigitals.net" > SiteCredit </a>    </p>
</footer>

    </main> <!-- /playground -->


    <!-- - - - - - - - - - - - - -->
    <!-- start of NOTIFICATIONS  -->
    <!-- - - - - - - - - - - - - -->
     <aside id="multi-panel">
      <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 100%;"><div class="container-fluid no-margin slimscroll" style="overflow: hidden; width: auto; height: 100%;">

        <ul id="multi-panel-tabs" class="nav nav-tabs" role="tablist">
          <li><a href="#" class="close-multi-panel"><i class="fa fa-indent"></i></a></li>
         <!-- <li role="presentation" class="active"><a href="#contacts" role="tab" id="contacts-tab" data-toggle="tab" aria-controls="contacts" aria-expanded="true">Contacts</a></li>-->
          <li role="presentation" class="active"><a href="#alerts" id="alerts-tab" role="tab" data-toggle="tab" aria-controls="alerts">Alerts</a></li>
        </ul> 

        <section class="panel ">
            
          <div id="multi-panel-tabs-content" class="tab-content">




            <!-- Chat -->
          <!--  <div role="tabpanel" class="tab-pane fade in active" id="contacts" aria-labelledby="contacts-tab">

              <div class="widget chat-widget list-group">
                <a class="list-group-item" href="#">
                  <span class="chat-status success"></span> Daenerys Targaryen <span class="label label-warning pull-right">13</span>
                </a>
              </div>

              <div class="widget chat-widget list-group">
                <a class="list-group-item" href="#">
                  <span class="chat-status success"></span> Tyrion Lannister
                </a>
              </div>

              <div class="widget chat-widget list-group">
                <a class="list-group-item" href="#">
                  <span class="chat-status warning"></span> Cersei Lannister <span class="label label-warning pull-right">2</span>
                </a>
              </div>

              <div class="widget chat-widget list-group">
                <a class="list-group-item" href="#">
                  <span class="chat-status danger"></span> Arya Stark
                </a>
              </div>

              <div class="widget chat-widget list-group">
                <a class="list-group-item" href="#">
                  <span class="chat-status danger"></span> Sansa Stark
                </a>
              </div>

            </div>--> <!-- / Chat -->

            <!-- Alerts -->
            <div role="tabpanel" class="tab-pane fade" id="alerts" aria-labelledby="alerts-tab">
              
            

              <!-- MESSAGES WIDGET -->
              <div class="widget messages-widget">
                <h4 class="widget-title">New Messages</h4>
                <ul class="list-group">

                
                </ul>
              </div> <!-- / MESSAGES WIDGET -->

              <!-- MESSAGES WIDGET -->
             <!-- / MESSAGES WIDGET -->


            </div> <!-- / Alerts -->

          </div>

        </section>


      </div><div class="slimScrollBar" style="background: rgb(0, 0, 0) none repeat scroll 0% 0%; width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 659px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; opacity: 0.2; z-index: 90; right: 1px;"></div></div>
    </aside>    <!-- - - - - - - - - - - - - -->
    <!-- start of NOTIFICATIONS  -->
    <!-- - - - - - - - - - - - - -->

    <div class="scroll-top" style="display: block;">
      <i class="ti-angle-up"></i>
    </div>
  </div> <!-- /animsition -->

  
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="dashboard_files/raphael-min.js"></script>
  <script src="dashboard_files/jquery-1.js"></script>
  <script src="dashboard_files/jquery-ui.js"></script>
  <script src="dashboard_files/bootstrap.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="dashboard_files/jquery.js"></script>
  <script src="dashboard_files/d3.js"></script>
  <!--<script src="dashboard_files/epoch.js"></script>-->

  <script src="dashboard_files/includes.js"></script>
  <script src="dashboard_files/sugarrush.js"></script>


<style type="text/css">
  .percentbar { background:#CCCCCC; border:1px solid #666666; height:30px;margin: 10px 0px 0px 10px;border-radius: 7px;border: none; }
.percentbar div { background: #5479AA; height: 30px; border-radius: 7px;border: medium none;}
</style>
</body></html>