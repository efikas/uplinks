<?php include('head.php'); ?>
<section id="page-title" class="row">

          <div class="col-md-8 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">
            <h1>REFERRAL LINK</h1>
            <p></p><div style="color:#900;font-weight:bold;" align="center"></div><p></p>
          </div>

             
             
          <div class="col-md-4 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">

            <ol class="breadcrumb pull-right no-margin-bottom">
              <li><a href="#">REFERRAL LINK</a></li>
              <li><a href="#">REFERRAL LINK</a></li>
            </ol>

          </div>
        </section>
        
        <div class="container-fluid">
          <div class="row">
       
            <div class="col-md-7 center-block animateme scrollme" style="float:none;" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">

           <form name="bankinfo" method="post">
			   
					<div class="panel panel-primary">
						
						<div class="panel-heading">
							<h3 class="panel-title">REFERRAL LINK</h3>
						</div>
					  
						<div class="panel-body" style="border:1px solid #ccc; border-bottom:3px solid #ccc;">
						
						<div class="text-center" style="padding:20px 20px ; font-color:000;">
							
							<a href="http://uplinks.biz/reg.php?<?php echo $myid;?>" rel="gallery">
						   http://uplinks.biz/reg.php?<?php echo $myid;?>						   </a>  <br>
						   <br>

							<a href="http://www.facebook.com/sharer.php?u=http://uplinks.biz/reg.php?<?php echo $myid;?>" target="_blank"><img src="assets/img/facebook.png" width="120"></a> &nbsp;

							<a href="http://twitter.com/share?url=http://uplinks.biz/reg.php?<?php echo $myid;?>" target="_blank"><img src="assets/img/twitter.png" width="120"></a> &nbsp;

							<a href="http://twitter.com/share?url=http://uplinks.biz/reg.php?<?php echo $myid;?>" target="_blank"><img src="assets/img/whatsapp.png" width="120"></a> &nbsp;
					  
						  
							<a href="https://plusone.google.com/_/+1/confirm?hl=en&amp;url=http://uplinks.biz/reg.php?<?php echo $myid;?>" target="_blank"><img src="assets/img/sg.png" width="120"></a>
							<br>

						</div>
						
					  </div>
					  
					</div>
                 
              
           </form>

            </div> <!-- / col-md-6 -->

          

          </div> <!-- / row -->

         

        </div>

<?php include('footer.php'); ?>