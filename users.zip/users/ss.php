
<!-- PAGE TITLE -->
<section id="page-title" class="row">

    <div class="col-md-8 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5" style="opacity: 1; transform: translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scale3d(1, 1, 1);">
        <!--<h1>My Withdrawal Request</h1>-->
        <!--<p><a href="#" target="_blank" class="btn btn-danger btn-sm">DataTables documentation</a></p>-->
    </div>

    <div class="col-md-4 animateme scrollme" style="float: right; opacity: 1; transform: translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scale3d(1, 1, 1);" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">

        <a target="_self" href="withdraw-request.php"><input name="update" value="New Request Click Here" class="btn btn-primary" type="submit"></a>

    </div>
</section> <!-- / PAGE TITLE -->
