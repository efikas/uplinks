<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);

    if( isset($_POST['send']) ) {
    $ema = $userRow['email']; 
    $mes = trim($_POST['mes']); 
    $added=date("Ymd his");
    $img = $userRow['email'].date("Ymd his").basename( $_FILES["img"]["name"]); 
    mysqli_query($dbc,"INSERT INTO msg(email,mes,img) VALUES('$ema','$mes','$img')");
        unset($ema);  
        
        $target_dir = "uploads/".$userRow['email'].$added;
        $target_file = $target_dir . basename($_FILES["img"]["name"]);
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

        if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
        echo "Your proof ". basename( $_FILES["img"]["name"]). " has been sent to admin.";
        } else {
        echo "Sorry, there was an error uploading your file.";
                }
    
    }
        
?>

<?php include('menu.php'); ?>

        
        <div style="padding-left:70px;margin-left:250px;" id="main">
	
	<div class="span10 offset1 ui-white padding-mid top-buffer-largest rounded-all">
		<h2 class="row text-center">Contact Us</h2>
		<hr>
		<div>
			
		<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off" enctype="multipart/form-data">
			<div class="control-group">
				<label for="photo" class="control-label">Proof of Payment</label>
				<div class="controls">
					<input  type="file" name="img" id="img" class="axBlank">
				</div>
			</div>
		<div class="control-group">
			<label for="name" class="control-label">
				message
			</label>
			<div class="controls">
				<textarea name="mes" id="mes" cols="30" rows="10" class="axBlank"></textarea>
			</div>
        
		</div>
             <div class="form-group">
            <button style="max-width:60px;margin-top:20px;" type="submit" class="btn btn-block btn-primary" name="send">Send</button>
            </div>
	</form>
		</div>
	</div>
</div>
</body>
</html>
<?php ob_end_flush(); ?>