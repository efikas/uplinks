<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 // reference http://www.niksofteng.com/2013/07/draw-hierarchical-tree-in-html-using.html
 // reference https://developers.google.com/chart/interactive/docs/gallery/orgchart
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
        $myid = $userRow['myid'];
        $emai = $userRow['email'];


$query = "SELECT * FROM `user_rank` WHERE `email` = '$emai'";
$res = mysqli_query($dbc, $query);
$row = mysqli_fetch_array($res);

$desc1 = $row[desc_1];
$desc2 = $row[desc_2];
$desc3 = $row[desc_3];
$desc4 = $row[desc_4];
$desc5 = $row[desc_5];
$desc6 = $row[desc_6];
$desc = array($desc1,$desc2,$desc3,$desc4,$desc5,$desc6);


$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc1'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc1 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc2'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc2 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc3'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc3 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc4'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc4 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc5'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc5 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc6'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc6 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
    
    if( isset($_POST['btn-paid']) ) {
    $ema = trim($_POST['email']);    
    mysqli_query($dbc, "DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc, "INSERT INTO to_receive(userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package) SELECT userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package FROM user_table WHERE email='$ema'");
        unset($ema);  
    
    }

    if( isset($_POST['spack']) ) {
    $mine= $userRow['email'];
    $q1 = "SELECT * FROM pending WHERE payto='$mine' AND topurge='0'";
    $q=mysqli_query($dbc, $q1);
    if(mysqli_num_rows($q)<1){
    $sp = trim($_POST['sp']);    
    mysqli_query($dbc, "INSERT INTO to_pay(userName,firstName,lastName,phoneNo,bankName,accName,accNo,email) SELECT userName,firstName,lastName,phoneNo,bankName,accName,accNo,email FROM user_table WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE to_pay SET package='$sp' WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE user_table SET package='$sp' WHERE email='$mine'");
    }
            unset($sp);  
    }


	if( isset($_POST['btn-purge']) ) {
        $email = trim($_POST['email']);    
    mysqli_query($dbc,"UPDATE pending SET topurge='1' WHERE email='$email'"); 
        unset($email);  
    }      
?>

<html>  
  <head>  
  
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userName']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css" />
<link rel="stylesheet" href="assets/css/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap-responsive.css" type="text/css"  />   
    <link rel="stylesheet" href="assets/css/bootstrap-responsive.min.css" type="text/css"  />
    
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="fiji_tourism_logo_detail.gif" rel="shortcut icon" type="image/vnd.microsoft.icon">

<!-- Google Fonts -->
<link href="css/css_003.css" rel="stylesheet" type="text/css">
<link href="css/css_004.css" rel="stylesheet" type="text/css">
<link href="css/css_002.css" rel="stylesheet" type="text/css">
    
    <!-- base css -->
<link rel="stylesheet" href="css/base.css" />
   <script type='text/javascript' src='https://www.google.com/jsapi'></script>  
   <script type='text/javascript'>  
    google.load('visualization', '1', {packages:['orgchart']});  
    google.setOnLoadCallback(drawChart);  
    function drawChart() {  
     var data = new google.visualization.DataTable();  
     data.addColumn('string', 'Node');  
     data.addColumn('string', 'Parent');  
     data.addRows([  
      ['<?php echo "My Emial:" .$emai;?>', ''],  
      ['<?php echo $desc1;?>', '<?php echo "My Emial:" .$emai;?>'],  
      ['<?php echo $desc2;?>', '<?php echo "My Emial:" .$emai;?>'], 
      ['<?php echo $desc3;?>', '<?php echo $desc1;?>'],  
      ['<?php echo $desc4;?>', '<?php echo $desc1;?>'], 
      ['<?php echo $desc5;?>', '<?php echo $desc2;?>'],  
      ['<?php echo $desc6;?>', '<?php echo $desc2;?>'],  
     ]);  
     var chart = new google.visualization.OrgChart(document.getElementById('chart_div'));  
     chart.draw(data);  
    }  
   </script>  
  </head>  
<body>

	<nav style="float:right;padding-left:100px;">
    

        <div id="navbar" class="navbar-collapse collapse">

          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['email']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
    </nav> 

    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
    
     
    
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    <div id="menu" >
 <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
</div>
    
<div id="mySidenav" class="sidenav" style="width:250px;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <ul class="nav lg-menu" id="main-nav" style="background:black;">
        <li><a href="index.php"> <i class="ti-dashboard"></i> <span>Main Dashboard</span></a></li>
        <li><a href="editprofile.php" class=""> <i class="ti-user"></i> <span>My Account</span> <i class="pull-right has-submenu ti-angle-right"></i></a>
        </li>
        
        <li><a href="#" class=""> <i class="ti-receipt"></i> <span>My Income Report </span> <i class="pull-right has-submenu ti-angle-right"></i> </a>
              <ul class="nav nav-submenu submenu-hidden" style="display: none;"> 
                <li><a href="sponsor-income.php">My Referral Income Report</a></li>
                <li><a href="level_income_report.php">My Matrix Income Report</a></li>
                 <li><a href="matching-income-report.php">My Matching Income Report</a></li>
     
              </ul>
            </li>

           
          

             <li><a href="#" class=""> <i class="ti-wallet"></i> <span>E-Wallet Section </span> <i class="pull-right has-submenu ti-angle-right"></i> </a>
              <ul class="nav nav-submenu submenu-hidden" style="display: none;">
                <li><a href="ewallet-transaction-history.php">Transaction History</a></li>
                <li><a href="previous_transaction_history.php">Previous Transaction History</a></li>
               <li><a href="check-ewallet-ballance.php">E-WALLET Balance</a></li>
             <li><a href="external-fund-tranfer.php">e-Wallet Fund Transfer</a></li>
               <li><a href="withdrawal-section.php">E-WALLET Withdrawal </a></li>
                <li><a href="add_fund_wallet.php">Add funds to wallet </a></li>

               
                 
                </ul>
            </li>


             <li><a href="direct-member-tree.php"> <i class="ti-vector"></i> <span>Genealogy Tree</span> <i class="pull-right has-submenu ti-angle-right"></i> </a>
            </li>
        <li> <a href="regnew_refer.php"> <i class="ti-desktop"></i> <span>Register Member</span></a> </li>

             <li><a href="contact.php"> <i class="ti-receipt"></i> <span>Support Management </span> <i class="pull-right has-submenu ti-angle-right"></i> </a>
            </li>

 
             <li><a href="#"> <i class="ti-file"></i> <span>Policy Section</span> <i class="pull-right has-submenu ti-angle-right"></i> </a>
              <ul class="nav nav-submenu submenu-hidden"> 
                <li><a href="terms-and-condition.php">Terms &amp; Conditions</a></li>
              </ul>
            </li>
       <a href="logout.php?logout">Logout</a>

           
           

          </ul>
</div>
