<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
        $myid = $userRow['myid'];


    if( isset($_POST['btn-paid']) ) {
    $ema = trim($_POST['email']);    
    mysqli_query($dbc, "DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc, "INSERT INTO to_receive(userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package) SELECT userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package FROM user_table WHERE email='$ema'");
        unset($ema);  
    
    }

    if( isset($_POST['spack']) ) {
    $mine= $userRow['email'];
    $q1 = "SELECT * FROM pending WHERE payto='$mine' AND topurge='0'";
    $q=mysqli_query($dbc, $q1);
    if(mysqli_num_rows($q)<1){
    $sp = trim($_POST['sp']);    
    mysqli_query($dbc, "INSERT INTO to_pay(userName,firstName,lastName,phoneNo,bankName,accName,accNo,email) SELECT userName,firstName,lastName,phoneNo,bankName,accName,accNo,email FROM user_table WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE to_pay SET package='$sp' WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE user_table SET package='$sp' WHERE email='$mine'");
    }
            unset($sp);  
    }


	if( isset($_POST['btn-purge']) ) {
        $email = trim($_POST['email']);    
    mysqli_query($dbc,"UPDATE pending SET topurge='1' WHERE email='$email'"); 
        unset($email);  
    }      
?>

<?php include('menu.php'); ?>
    <div id="main" style="margin-left:250px;">
    <div style="float:left;padding:40px;">
<div  style="float:left; padding-right:30px;">
<div class="card" style="width:92%;max-width:300px;">
    <h3>Welcome <?php echo $userRow['userName']; ?></h3>  
  <img src="img/img_avatar.png" alt="Avatar" style="width:100%;opacity:0.85">
  <div class="container">
  <h3><?php echo $userRow['firstName'].' '.$userRow['lastName']; ?></h3>
<ul class="list-unstyled user_data">
<li> <i class="fa fa-user user-profile-icon"></i> Username: <?php echo $userRow['userName']; ?></li>
<li class="m-top-xs"> <i class="fa fa-phone user-profile-icon"></i> <?php echo $userRow['phoneNo']; ?> </li>
<li><i class="fa fa-envelope user-profile-icon"></i> <?php echo $userRow['email']; ?></li>
</ul>
  </div>
</div>
</div>
        <div  style="float:right;">
            <div class="card" style="width:70%;max-width:500px;border-radius:5px">
                <h3>The following people are directly under you:</h3>
                <div class="container">
                    <div  class="span6 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
                        <table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
                            <thead>
                                <tr><th>s.no</th><th>name</th><th>phone</th><th>date</th><th><div class='noPrint'>action</div></th></tr>
                            </thead>
            	          <?php
                            $me = $userRow['email'];
                            $myid = $userRow['myid'];
                            $query = "SELECT * FROM user_rank WHERE superior_id='$myid' ";
                            $query=mysqli_query($dbc, $query) or die('error changing purge setting');
                            $i= 1;
                            while ($row = mysqli_fetch_array($query)) {
                                $under_meid[$i] =  $row['myid'];
                             $quer=mysqli_query($dbc, "SELECT * FROM user_table WHERE myid='$under_meid[$i]'");
                            $ron = mysqli_fetch_array($quer);
                            $email[$i] =  $ron['email'];                               
                            $pn[$i]= $ron['phoneNo']; 
                            $name[$i]= $ron['firstName'].' '.$ron['lastName'];
                            $date[$i] =  $ron['added'];
                               
                              
                            ?>
                            <tr>
                                
                                <td><?php echo $i;?></td>
                                <td><?php echo $name[$i];?></td>
                                <td><?php echo $pn[$i];?></td>
                                <td><?php echo $date[$i];?></td>

                                <td> 
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
                                <div class="form-group">
                               <input type="hidden" name="email" value="<?php echo $email[$i]; ?>" />
                                <button style=" background-color: #f44336;" type="submit" class="btn btn-block" name="btn-purge">Report</button>
                            </div> </form></td>
  
                            </tr>
            
                            <?php $i= $i+1; } ?>
                            <?php $i= 0; ?>
                            </table>	
                    </div>
                </div>
            </div>  
        </div>
        </div>
    <br/>
<div style="float:left;padding:40px;">    
    <div  style="float:left; padding-right:30px;">
        <div class="card" style="width:92%;max-width:300px;">
    <h2>Marketing Tool</h2>  

    <h4>Share this with poeple you want to refer to register</h4>
Referal link: <input type="text" value="<?php echo $url.'/reg.php?ref='.$myid;  ?>" ></input>
        </div>
    </div>
<div  style="float:right;">
<div class="card" style="width:100%;max-width:600px;border-radius:5px">
  <div class="container">
		
	<div class="span6 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
		  <h3>You are directly under</h3>  

        <table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
            <thead>
                <tr>
                    <th>name</th><th>phone</th><th>Bank</th><th>Account Name</th><th>Account Number</th><th>date</th></tr>
            </thead>
            	          <?php
            $myid = $userRow['myid'];
      $query=mysqli_query($dbc,"SELECT * FROM user_rank WHERE myid='$myid'");
             $row = mysqli_fetch_array($query);
            $my_superior =  $row['superior_id'];
            $quer=mysqli_query($dbc, "SELECT * FROM user_table WHERE myid='$my_superior'");
             $ron = mysqli_fetch_array($quer); ?>
                   <tr>
                   <td><?php echo $ron['firstName'].' '.$ron['lastName'];?></td>
                   <td><?php echo $ron['phoneNo'];?></td>
                   <td><?php echo $ron['bankName'];?></td>
                   <td><?php echo $ron['accName'];?></td>
                   <td><?php echo $ron['accNo'];?></td>
                   <td><?php echo $ron['added'];?></td>
                   </tr>
        </table>	
      </div>
      
 </div>
    
</div>
</div>
    
</div>  

    <br/>
<div style="float:left;padding:40px;">    
    <div  style="float:left; padding-right:30px;">
        <div class="card" style="width:92%;max-width:800px;">
    <h2 style="text-align: center;">Your Downward Chain</h2>
    
   <div style="margin-left:25px;" id='chart_div'></div>   
</div> 
</div> 
</div>
</div>
    
</body>
</html>
<?php ob_end_flush(); ?>