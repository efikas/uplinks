<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	$ut = $_SESSION['userType'];
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	} else if( $ut== '2') {
		header("Location: home.php");
		exit;
	}
	// select loggedin users detail
$ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap-responsive.css" type="text/css"  />   
    <link rel="stylesheet" href="assets/css/bootstrap-responsive.min.css" type="text/css"  />
    
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="fiji_tourism_logo_detail.gif" rel="shortcut icon" type="image/vnd.microsoft.icon">

<!-- Google Fonts -->
<link href="css/css_003.css" rel="stylesheet" type="text/css">
<link href="css/css_004.css" rel="stylesheet" type="text/css">
<link href="css/css_002.css" rel="stylesheet" type="text/css">
        <!-- base css -->
        <link rel="stylesheet" href="css/base.css" />
</head>
<body>

	<nav style="float:right;padding-left:100px;">
    

        <div id="navbar" class="navbar-collapse collapse">

          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['email']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
    </nav> 

    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
    
       
    
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    <div id="menu">
 <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
</div>
    
    
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="admin.php">Dashboard</a>
  <a href="listmember.php">List of members</a>
  <a href="defaulter.php">View Defaulters</a>
  <a href="adminpair.php">Admin Pairlist</a>
  <a href="addpair.php">Add Pair</a>
  <a href="admin_history.php">History</a>
  <a href="packages.php">Set Packages</a>
  <a href="logout.php?logout">Logout</a>
</div>
    
    <div id="main">
    <div style="float:left;padding:40px;">
<div  style="float:left; padding-right:30px;">
<div class="card" style="width:92%;max-width:300px;">
    <h3>Welcome <?php echo $userRow['userName']; ?></h3>  
  <img src="img/img_avatar.png" alt="Avatar" style="width:100%;opacity:0.85">
  <div class="container">
  <p>Status: Awaiting payment</p>    
  </div>
</div>
</div>
<div  style="float:right;">
<div class="card" style="width:70%;max-width:500px;border-radius:5px">
  <h3>You're to Receive payment from:</h3>  
  <div class="container">
		
	  <div  class="span5 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">   	
		<table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
            <thead>
                <tr>
                    <th>s.no</th><th>name</th><th>sex</th><th>phone</th><th>date</th><th><div class='noPrint'>action</div></th></tr>
            </thead>
        </table>	
      </div>
     </div>  

</div>
</div>
    </div>
    <br/>
<div style="float:left;padding:40px;">    
    <div  style="float:left; padding-right:130px;">
        <div class="card" style="width:132%;max-width:400px;">
    <h3>Make another donation</h3>  

<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
<select class="form-control"name="id">
<?php 
$sql = mysqli_query($dbc,"SELECT * FROM packages");
while ($row = mysqli_fetch_array($sql)){
    
echo "<option value=".$row['pamount'].">" . $row['pname'] . "</option>";
}
?>
</select>  

    <br/>
    <div class="form-group">
        <button type="submit" class="btn btn-primary" name="spack">Choose Package</button>
    </div>

</form>
        </div>
    </div>
<div  style="float:right;">
<div class="card" style="width:100%;max-width:400px;border-radius:5px">
  <h3>When paired, account to pay to appears here</h3>  
  <div class="container">
		
	<div class="span5 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
		
		<h2>No pending payments.</h2>	</div>
      
 </div>
    
</div>
</div>
    
</div>    
</div>
    
</body>
</html>
<?php ob_end_flush(); ?>