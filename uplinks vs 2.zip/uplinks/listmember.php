<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	$ut = $_SESSION['userType'];
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	} else if( $ut== '2') {
		header("Location: home.php");
		exit;
	}
	// select loggedin users detail
$ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);

	if( isset($_POST['btn-delete']) ) {
        $email = trim($_POST['email']);    
        mysql_query("DELETE pending WHERE email='$email'"); 
        mysql_query("DELETE user_table WHERE email='$email'"); 
        unset($email);  
    } 

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap-responsive.css" type="text/css"  />   
    <link rel="stylesheet" href="assets/css/bootstrap-responsive.min.css" type="text/css"  />
    
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="fiji_tourism_logo_detail.gif" rel="shortcut icon" type="image/vnd.microsoft.icon">

<!-- Google Fonts -->
<link href="css/css_003.css" rel="stylesheet" type="text/css">
<link href="css/css_004.css" rel="stylesheet" type="text/css">
<link href="css/css_002.css" rel="stylesheet" type="text/css">
        <!-- base css -->
        <link rel="stylesheet" href="css/base.css" />
</head>
<body>

	<nav style="float:right;padding-left:100px;">
    

        <div id="navbar" class="navbar-collapse collapse">

          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['email']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
    </nav> 

    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="admin.php">Dashboard</a>
  <a href="listmember.php">List of members</a>
  <a href="defaulter.php">View Defaulters</a>
  <a href="adminpair.php">Admin Pairlist</a>
  <a href="addpair.php">Add Pair</a>
      <a href="admin_msg.php">Messages</a>
  <a href="admin_history.html">History</a>
  <a href="packages.php">Set Packages</a>
  <a href="logout.php?logout">Logout</a>
</div>
   

<div id="main" style="padding-left:40px;">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; menu</span>
   
    <form>
    <label> Search Member</label>
    <input type="text"></input>    
    
    <input type="submit"> 
    </form>
    <br/>
    <br/>

    <div class="container">
                    <div  class="span9 padding-mid" style="font-size:20px; border-margin:0px; border-padding:0; overflow-x: auto; cellspacing:0px;">
                        <table border="0" cellpadding="0" cellspacing="0"  id="table" class="table table-responsive  table-hover">
                            <thead>
                                <tr><th>S.No</th><th>Name</th><th>Phone</th><th>Email</th><th>To Purge</th><th>Time Purged</th><th><div class='noPrint'>action</div></th></tr>
                            </thead>
            	          <?php
                            $me = $userRow['email'];

                            $query=mysqli_query($dbc,"SELECT * FROM user_table");
                            $i= 1;
                            while ($row = mysqli_fetch_array($query)) {
                                $email[$i] =  $row['email'];                               
                                $pn[$i]= $row['phoneNo']; 
                                $name[$i]= $row['firstName'].' '.$row['lastName'];
                                
                            $quer=mysqli_query($dbc,"SELECT * FROM pending WHERE email='$email[$i]'");
                            $ron = mysqli_fetch_array($quer);
                            $purge[$i]= $ron['topurge']; 
                            $datepurged[$i]= $ron['added']; 
                              
                            ?>
                            <tr>
                                
                                <td><?php echo $i;?></td>
                                <td><?php echo $name[$i];?></td>
                                <td><?php echo $pn[$i];?></td>
                                <td><?php echo $email[$i];?></td>                                
                                <td><?php if($purge[$i]==1){echo '  '.Yes;} else{ echo   No;}?></td>
                                <td><?php echo $datepurged[$i];?></td>
                                <td>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
                                <div class="form-group">
                                <?php $email[$i] =  $row['email']; ?>  
                                <input type="hidden" name="email" value="<?php echo $email[$i]; ?>" />
                                <button type="submit" class="btn btn-block btn-primary" name="btn-delete">Delete</button>
                                </div>
                                
                            </form>
                                </td>
  
                            </tr>
            
                            <?php $i= $i+1; } ?>
                            <?php $i= 0; ?>
                            </table>	
                    </div>
                </div>
    </div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
    
  

</html>
<?php ob_end_flush(); ?>