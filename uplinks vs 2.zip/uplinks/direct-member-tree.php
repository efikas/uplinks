
<?php include('menu.php'); ?>
    <div id="main" style="margin-left:250px;">
    <h1 style="text-align: center;padding-bottom: 50px;">Your Direct Downward Tree</h1>
 
   <div style="float:center;margin-left:25px; " id='chart_div'></div>  
   </div>
  </body>  
 </html>  