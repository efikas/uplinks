<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
$ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
?>

<?php include('menu.php'); ?>

<?php 

        $message = "";
    if( isset($_POST['addfundstowallet']) ) {
        
        $message = "Kindly pay to our account, we'll add the amount to your wallet as soon as we are notified of the transaction";
        }

?>
	
        <div class="content">
		<div class="card">
            	<div class="container">
                	<div class="row">
                    	
                    	<div class="col-md-4 ">
                        	<div class="media">
                            	<div class="media-left">
                                	<div class="icon icon-danger">
                                    	<i class="ti ti-user"></i>
                                	</div>
                            	</div>
                            	<div class="media-body">
                                	<h5>How to Add funds to your account</h5>
									<p> Funds you add to your account can be used when you want to register new member</p>
                                	<p>Please fill the form: <ul>
									<li>Indicate the amount you want to add to your wallet</li>
									<li>choose your payment method</li>
									<li>Confirm the amount to be paid and proceed to payment</li> 
									<li> Make Payment</li>
									
                            	</div>
                        	</div>
                    	</div>
                    	<div class="col-md-6" >
							<div class="all_form">
                        	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                            <input hidden="hidden" name="addfundstowallet" id="addfundstowallet"/>
                            	<div class="card card-plain">
                                	<div class="content">
									
                                    <div class="payment_form">
									<div>
                                    	<div class="form-group">
										<span class="form-errors" id="airtime_amount_err"></span>
                                        	<input type="text" id="amount" name="amount" placeholder="Amount to add to Wallet" class="form-control number_box"  required/>
                                    	</div>
                                    	<div class="form-group">
                                        	<select id="payment_method"  class="form-control"  required >
											<option value="">Select a Payment method
											</option>
											<option value="online">Secure Online payment
											</option>
											<option value="bank">Bank Deposit
											</option>
											<option value="transfer">Bank Transfer
											</option>
											<option value="paypal">PayPal
											</option>
											<option value="cash">Cash to our office
											</option>
											<option value="quickteller">Quickteller
											</option>
											</select>
                                    	</div>
                                    	
                                	</div>
                                	<div class="footer text-center">
                                    
                                    <input type="button" class="btn btn-fill btn-danger btn-wd" value="Confirm" onclick="confirmpay()" id="but" />
                                	</div>
									</div>
                  					</div>	
                            	
							<div style="display: none;" class="panel-body" id="pay_details">
                                   <div class="col-md-12">
                                    <strong>Add funds to wallet</strong>
                                    <div class="pull-right"><span>&#8358;</span><span id="fund_added" ></span></div>
                                </div>
                                <div  class="col-md-12">
                                    <small>Token charges on Payment </small> 
                                    <div class="pull-right"><span></span><span class="form-errors" id="error_charges"></span><span id="charge" ></span></div>
                                </div>
                                
                                <div class="col-md-12">
                                    <strong>Total to be paid</strong>
                                    <div class="pull-right"><span>&#8358;</span><span id="total_payment"  ></span></div>
                                    <hr>
                                </div>
                                <button type="submit" id="button_proceed" class="btn btn-primary btn-lg btn-block">Proceed to payment <img src="./images/loading.gif" width="20px" id="loader" height="15px"/></button>
                                
                        </div>
                        
                                <?php echo $message;?>
                            	</div>
                        	</form>
                                              <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="paypal">
    <!-- Prepopulate the PayPal checkout page with customer details, -->
    <input type="hidden" name="first_name" value="<?php echo Firstname?>">
    <input type="hidden" name="last_name" value="<?php echo Lastname?>">
    <input type="hidden" name="email" value="<?php echo Email?>">
    <input type="hidden" name="address1" value="<?php echo Address?>">
    <input type="hidden" name="address2" value="<?php echo Address2?>">
    <input type="hidden" name="city" value="<?php echo City?>">
    <input type="hidden" name="zip" value="<?php echo Postcode?>">
    <input type="hidden" name="day_phone_a" value="">
    <input type="hidden" name="day_phone_b" value="<?php echo Mobile?>">

    <!-- We don't need to use _ext-enter anymore to prepopulate pages -->
    <!-- cmd = _xclick will automatically pre populate pages -->
    <!-- More information: https://www.x.com/docs/DOC-1332 -->
    <input type="hidden" name="cmd" value="_xclick" />
    <input type="hidden" name="business" value="paypal@email.com" />
    <input type="hidden" name="cbt" value="Return to Your Business Name" />
    <input type="hidden" name="currency_code" value="GBP" />

    <!-- Allow the customer to enter the desired quantity -->
    <input type="hidden" name="quantity" value="1" />
    <input type="hidden" name="item_name" value="Name of Item" />

    <!-- Custom value you want to send and process back in the IPN -->
    <input type="hidden" name="custom" value="<?php echo session_id();?>" />

    <input type="hidden" name="shipping" value="<?php echo $shipping_price; ?>" />
    <input type="hidden" name="invoice" value="<?php echo $invoice_id ?>" />
    <input type="hidden" name="amount" value="<?php echo $total_order_price; ?>" />
    <input type="hidden" name="return" value="http://<?php echo $_SERVER['SERVER_NAME']?>/shop/paypal/thankyou"/>
    <input type="hidden" name="cancel_return" value="http://<?php echo $_SERVER['SERVER_NAME']?>/shop/paypal/cancelled" />

    <!-- Where to send the PayPal IPN to. -->
    <input type="hidden" name="notify_url" value="http://<?php echo $_SERVER['SERVER_NAME']?>/shop/paypal/process" />
    <input type="hidden" name="submit">
</form>
		
							</div>
                    	</div>
            	</div>
        	</div>
        	</div>
            </div>


        <footer style="clear:both;" class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="#">
                                Pebles
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               For Uplinks
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Powered by Uplinks. Copyrights 2017. All Rights Reserved.
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with<i class="fa fa-heart heart"></i> by <a href="#">Pebles</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
<script>

function confirmpay() {
   
			amount = $("input[name='amount']").val();
            token = 1;
			payment_method = $("#payment_method").val(); 
            $("#charge").html(token);
            total = parseInt(amount) + parseInt(token);
    
            $("#fund_added").html(amount);
            $("#total_payment").html(total);
        document.getElementById("pay_details").style.display = "block";
        

}  
</script>
