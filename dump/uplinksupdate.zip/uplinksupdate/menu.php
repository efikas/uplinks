<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 // reference http://www.niksofteng.com/2013/07/draw-hierarchical-tree-in-html-using.html
 // reference https://developers.google.com/chart/interactive/docs/gallery/orgchart
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
        $myid = $userRow['myid'];
        $emai = $userRow['email'];
        $my_userName = $userRow['userName'];
        $my_firstName = $userRow['firstName'];
        $my_lastName = $userRow['lastName'];
        $my_occupation = $userRow['occupation'];
        $my_address = $userRow['address'];
        $my_city = $userRow['city'];
        $my_state = $userRow['state'];
        $my_phoneNo = $userRow['phoneNo'];
        $my_bankName = $userRow['bankName'];
        $my_accNo = $userRow['accNo'];
        $my_accName = $userRow['accName'];
        $my_urltoimg = $userRow['urltoimg'];
        $my_dob = $userRow['dob'];
        $my_marital = $userRow['marital'];
        $my_gender = $userRow['gender'];
        $my_status = $userRow['status'];
        $name = $userRow['lastName'].' '.$userRow['firstName'];


$query = "SELECT * FROM `user_rank` WHERE `email` = '$emai'";
$res = mysqli_query($dbc, $query);
$row = mysqli_fetch_array($res);

$my_balance = $row[balance];
$my_stage = $row[stage];
$my_level = $row[level];

$desc1 = $row[desc_1];
$desc2 = $row[desc_2];
$desc3 = $row[desc_3];
$desc4 = $row[desc_4];
$desc5 = $row[desc_5];
$desc6 = $row[desc_6];
$desc = array($desc1,$desc2,$desc3,$desc4,$desc5,$desc6);


$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc1'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc1 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc2'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc2 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc3'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc3 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc4'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc4 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc5'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc5 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
  

$query = "SELECT * FROM `user_table` WHERE `myid` = '$desc6'";
$res = mysqli_query($dbc, $query);
$user_row = mysqli_fetch_array($res);
 $desc6 =   $user_row[email]." ".$user_row[firstName]." ".$user_row[lastName]." ".$user_row[myid];
    
    if( isset($_POST['btn-paid']) ) {
    $ema = trim($_POST['email']);    
    mysqli_query($dbc, "DELETE FROM pending WHERE email='$ema'");
    mysqli_query($dbc, "INSERT INTO to_receive(userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package) SELECT userName,firstName,lastName,phoneNo,accName,accNo,email,bankName,package FROM user_table WHERE email='$ema'");
        unset($ema);  
    
    }

    if( isset($_POST['spack']) ) {
    $mine= $userRow['email'];
    $q1 = "SELECT * FROM pending WHERE payto='$mine' AND topurge='0'";
    $q=mysqli_query($dbc, $q1);
    if(mysqli_num_rows($q)<1){
    $sp = trim($_POST['sp']);    
    mysqli_query($dbc, "INSERT INTO to_pay(userName,firstName,lastName,phoneNo,bankName,accName,accNo,email) SELECT userName,firstName,lastName,phoneNo,bankName,accName,accNo,email FROM user_table WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE to_pay SET package='$sp' WHERE email='$mine'");
    mysqli_query($dbc, "UPDATE user_table SET package='$sp' WHERE email='$mine'");
    }
            unset($sp);  
    }


	if( isset($_POST['btn-purge']) ) {
        $email = trim($_POST['email']);    
    mysqli_query($dbc,"UPDATE pending SET topurge='1' WHERE email='$email'"); 
        unset($email);  
    }      
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <title>Welcome - <?php echo $userRow['userName']; ?></title>
    
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">


    <!-- base css -->
<link rel="stylesheet" href="css/base.css" />
   <script type='text/javascript' src='https://www.google.com/jsapi'></script>  
   <script type='text/javascript'>  
    google.load('visualization', '1', {packages:['orgchart']});  
    google.setOnLoadCallback(drawChart);  
    function drawChart() {  
     var data = new google.visualization.DataTable();  
     data.addColumn('string', 'Node');  
     data.addColumn('string', 'Parent');  
     data.addRows([  
      ['<?php echo "My Emial:" .$emai;?>', ''],  
      ['<?php echo $desc1;?>', '<?php echo "My Emial:" .$emai;?>'],  
      ['<?php echo $desc2;?>', '<?php echo "My Emial:" .$emai;?>'], 
      ['<?php echo $desc3;?>', '<?php echo $desc1;?>'],  
      ['<?php echo $desc4;?>', '<?php echo $desc1;?>'], 
      ['<?php echo $desc5;?>', '<?php echo $desc2;?>'],  
      ['<?php echo $desc6;?>', '<?php echo $desc2;?>'],  
     ]);  
     var chart = new google.visualization.OrgChart(document.getElementById('chart_div'));  
     chart.draw(data);  
    }  
   </script>
   
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>  
</head>
<body>
    
<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    Uplinks International
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="home.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="editprofile.php">
                        <i class="ti-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li>
                    <a href="income_report.php">
                        <i class="ti-stats-up"></i>
                        <p>My Income Report</p>
                    </a>
                </li>
                <li>
                    <a href="ewallet-transaction-history.php">
                        <i class="ti-direction-alt"></i>
                        <p>Transaction History</p>
                    </a>
                </li>
                <li>
                    <a href="check-ewallet-ballance.php">
                        <i class="ti-server"></i>
                        <p>E-WALLET Balance</p>
                    </a>
                </li>
                <li>
                    <a href="fund_wallet.php">
                        <i class="ti-money"></i>
                        <p>Fund Wallet</p>
                    </a>
                </li>
                <li>
                    <a href="external-fund-tranfer.php">
                        <i class="ti-money"></i>
                        <p>Fund Transfer</p>
                    </a>
                </li>
                <li>
                    <a href="withdraw-request.php">
                        <i class="ti-printer"></i>
                        <p>E-WALLET Withdrawal</p>
                    </a>
                </li>
                <li>
                    <a href="logout.php?logout">
                        <i class="ti-bell"></i>
                        <p>Logout</p>
                    </a>
                </li>
                <li>
                    <a href="notifications.html">
                        <i class="ti-bell"></i>
                        <p>Notifications</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>



    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#"> <?php  echo $name ;?></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stage: <?php echo $my_stage;?></p>
                            </a>
                        </li> 
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Level: <?php echo $my_level;?></p>
                            </a>
                        </li>
						<li>
                    <a href="logout.php?logout">
                        <i class="ti-bell"></i>
                        <p>Logout</p>
                    </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
