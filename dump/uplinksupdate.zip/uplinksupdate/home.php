<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
    $ses = $_SESSION['user'];
	$res=mysqli_query($dbc,"SELECT * FROM user_table WHERE email='$ses'");
	$userRow=mysqli_fetch_array($res);
        $myid = $userRow['myid'];


   
?>

<?php include('menu.php'); ?>

      <?php 
    if( isset($_POST['btn-approve']) ) {
        
        if($my_balance >= 32){
        $newbalance = $my_balance - 32;
    $ema = trim($_POST['email']);    
    mysqli_query($dbc, "UPDATE user_table SET `status`= 'paid' WHERE email='$ema'");
    mysqli_query($dbc, "UPDATE user_rank SET `status`= 'paid' WHERE email='$ema'");
    
    mysqli_query($dbc, "UPDATE user_rank SET  `balance`= '$newbalance' WHERE email='$emai'");
        unset($ema);  
    
    }
    }
    
    if( isset($_POST['btn-approve_me']) ) {
        
        if($my_balance >= 32){
     
        $newbalance = $my_balance - 32;
    mysqli_query($dbc, "UPDATE user_table SET `status`= 'paid' WHERE email='$emai'");
    mysqli_query($dbc, "UPDATE user_rank SET `status`= 'paid' WHERE email='$emai'");
    mysqli_query($dbc, "UPDATE user_rank SET  `balance`= '$newbalance' WHERE email='$emai'");       
        }else{
        
            $pay_error = "insufficient fund";
        }
        
        }
    ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">

    <div style="float:left;">
<div  style="float:left; padding-right:30px;">
<div class="card" style="width:92%;max-width:300px;">
    <h3>Welcome <?php echo $userRow['userName']; ?></h3>  
  <img src="img/img_avatar.png" alt="Avatar" style="width:100%;opacity:0.85"/>
  <div class="container">
  <h3><?php echo $userRow['firstName'].' '.$userRow['lastName']; ?></h3>
<ul class="list-unstyled user_data">
<li> <i class="fa fa-user user-profile-icon"></i> Username: <?php echo $userRow['userName']; ?></li>
<li class="m-top-xs"> <i class="fa fa-phone user-profile-icon"></i> <?php echo $userRow['phoneNo']; ?> </li>
<li><i class="fa fa-envelope user-profile-icon"></i> <?php echo $userRow['email']; ?></li>
<?php if($my_status == "paid"){}
else{
    ?>
    <div style="color: red;">
  <p>You are not yet a comfirmed </p>
  <p>member, kindly fund your wallet  </p> 
  <p>and click Pay from wallet below</p>
  <p>Alternatively: pay the user who </p>
  <p>referred you, in cash</p> 
  <p>and ask the user to transfer </p>
  <p>fund to your wallet</p>
    </div>
    
  Balance: $ <?php echo $my_balance; ?>
      <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
      
     <button style=" background-color: greenyellow;" type="submit"  name="btn-approve_me">Pay From Wallet</button>
       </form>  
    <?php
}
?>
</ul>
  </div>
</div>
</div>
        <div  style="float:right;">
        
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                 <h3>The following people are directly under you:</h3>
                                 <p>Kindly note that, for each member you approve ,<br />
                                  an amount of $32 will be deducted from your wallet</p>
                                  <p>except if the user already made the payment after registering</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                            
                                <table class="table table-striped">
                                    <thead>
                                <tr><th>s.no</th><th>name</th><th>phone</th><th>date</th><th><div class='noPrint'>action</div></th></tr>
                            </thead>
                                    <?php
                            $me = $userRow['email'];
                            $myid = $userRow['myid'];
                            $query = "SELECT * FROM user_rank WHERE superior_id='$myid' ";
                            $query=mysqli_query($dbc, $query) or die('error selecting user');
                            $i= 1;
                            while ($row = mysqli_fetch_array($query)) {
                                $under_meid[$i] =  $row['myid'];
                             $quer=mysqli_query($dbc, "SELECT * FROM user_table WHERE myid='$under_meid[$i]'");
                            $ron = mysqli_fetch_array($quer);
                            $email[$i] =  $ron['email'];                               
                            $pn[$i]= $ron['phoneNo']; 
                            $nam[$i]= $ron['firstName'].' '.$ron['lastName'];
                            $date[$i] =  $ron['added'];
                            $status[$i] =  $ron['status'];
                               
                              
                            ?>
                                    <tbody>
                         
                            <tr>
                                
                                <td><?php echo $i;?></td>
                                <td><?php echo $nam[$i];?></td>
                                <td><?php echo $pn[$i];?></td>
                                <td><?php echo $date[$i];?></td>

                                <td> 
                                 
                                <?php if($status[$i] == "paid"){ ?>
                                    <button style=" background-color: greenyellow;" type="submit" class="btn btn-block" name="btn">Paid and Approved</button>
                                  <?php  
                                }
                                else{ ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
                                <div class="form-group">
                               <input type="hidden" name="email" value="<?php echo $email[$i]; ?>" />
                                <button style=" background-color: greenyellow;" type="submit" class="btn btn-block" name="btn-approve">Approve</button>
                            </div> </form> <?php } ?>
                            </td>
  
                            </tr>
            
                            <?php $i= $i+1; } ?>
                            <?php $i= 0; ?>
                            	
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    </div>
</div>
              
        </div>
        </div>
    <br/>
<div style="clear:both;float:left;">    
    <div  style="float:left; padding-right:20px;">
        <div class="card" style="width:92%;max-width:300px;">
    <h2>Marketing Tool</h2>  

    <h4>Share this with poeple you want to refer to register</h4>
Referal link: <input type="text" value="<?php echo $url.'/reg.php?ref='.$myid;  ?>" ></input>
        </div>
    </div>
        <div  style="float:right;">
        
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                 <h3>You are directly under:</h3>
                            </div>
                            <div class="content table-responsive table-full-width">
                            
                                <table class="table table-striped">
                                    <thead>
                <tr>
                    <th>name</th><th>phone</th><th>Bank</th><th>Account Name</th><th>Account Number</th><th>date</th></tr>
            </thead>
                         <tbody>
            	          <?php
            $myid = $userRow['myid'];
      $query=mysqli_query($dbc,"SELECT * FROM user_rank WHERE myid='$myid'");
             $row = mysqli_fetch_array($query);
            $my_superior =  $row['superior_id'];
            $quer=mysqli_query($dbc, "SELECT * FROM user_table WHERE myid='$my_superior'");
             $ron = mysqli_fetch_array($quer); ?>
                   <tr>
                   <td><?php echo $ron['firstName'].' '.$ron['lastName'];?></td>
                   <td><?php echo $ron['phoneNo'];?></td>
                   <td><?php echo $ron['bankName'];?></td>
                   <td><?php echo $ron['accName'];?></td>
                   <td><?php echo $ron['accNo'];?></td>
                   <td><?php echo $ron['added'];?></td>
                   </tr>	
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    </div>
</div>
              
        </div>
</div>  

    <br/>
<div style="clear:both;float:left;padding:40px;">    
    <div  style="float:left; padding-right:30px;">
        <div class="card" style="width:92%;max-width:800px;">
    <h2 style="text-align: center;">Your Downward Chain</h2>
    
   <div style="margin-left:25px;" id='chart_div'></div>   
</div> 
</div> 
</div>



</div>
</div>
</div>

            <footer style="clear:both;" class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="#">
                                Pebles
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               For Uplinks
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Powered by Uplinks. Copyrights 2017. All Rights Reserved.
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with<i class="fa fa-heart heart"></i> by <a href="#">Pebles</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>

<?php ob_end_flush(); ?>