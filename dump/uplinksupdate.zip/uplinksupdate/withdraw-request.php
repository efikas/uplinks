<?php

/**
 * @author Akintola Oluwaseun Je
 * @copyright 2017
 */



?>

<?php include('menu.php'); ?>
<script>
                    
function confirmpay() {
   
        document.getElementById("pay_details").style.display = "block";

}                    
</script>
  
        <div class="content">
            <div class="container-fluid">
                <div class="row">

	<div id="main" >
<main id="playground">

        <!-- PAGE TITLE -->
        <section id="page-title" class="row">

          <div class="col-md-8 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">
            <!--<h1>Withdrawal Request</h1>-->
            <p></p><div style="color:#900;font-weight:bold;" align="center"></div><p></p>
          </div>

             
             
          <div class="col-md-4 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">

            <ol class="breadcrumb pull-right no-margin-bottom">
              <!--<li><a href="#">e-Wallet</a></li>
              <li><a href="#">e-Wallet Withdrawal Request</a></li>-->
            </ol>

          </div>
        </section> <!-- / PAGE TITLE -->

        <div class="container-fluid">
          <div class="row">
       
            <div class="col-md-8 animateme scrollme" style="float:none; margin-left:auto; margin-right:auto;" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">
<div class="card">
            	<div class="container">
                	<div class="row">
                    	<div class="col-md-6" >
							<div class="all_form">
                        	<form name="withdraw_method" method="#" action="#">
                            	<div class="card card-plain">
                                	<div class="content">
									
                                    <div class="payment_form">
									<div>
                                    	<div class="form-group">
										<span class="form-errors" id="airtime_amount_err"></span>
                                        	<input type="text" id="amount" name="amount" placeholder="Amount to withdraw from Wallet" class="form-control number_box"  required/>
                                    	</div>
                                    	<div class="form-group">
                                        	<select id="payment_method"  class="form-control"  required >
											<option value="">Select a withdraw method
											</option>
											<option value="transfer">Bank Transfer
											</option>
											<option value="paypal">PayPal
											</option>
											</select>
                                    	</div>
                                    	
                                	</div>
                                    
                                	<div class="footer text-center">
                                    
                                    <input type="button" class="btn btn-fill btn-danger btn-wd" value="Confirm" onclick="confirmpay()" id="but" />
                                	</div>
									</div>
							</div>		
							<div style="display: none;" class="panel-body" id="pay_details">
                                   <div class="col-md-12">
                                    <strong>Add funds to wallet</strong>
                                    <div class="pull-right"><span>&#8358;</span><span id="fund_added" ></span></div>
                                </div>
                                <div  class="col-md-12">
                                    <small>Token charges on Withdraw </small> 
                                    <div class="pull-right"><span></span><span ><span class="form-errors" id="error_for_the_boys"></span><input type="text"  style="width:70px;" value="" class="form-control number_box" id="for_the_boys" /></span></div>
                                </div>
                                
                                <div class="col-md-12">
                                    <strong>Total to be paid</strong>
                                    <div class="pull-right"><span>&#8358;</span><span id="total_payment"  ></span></div>
                                    <hr>
                                </div>
                                
                                <button type="button" id="button_proceed" class="btn btn-primary btn-lg btn-block">Proceed to payment <img src="./images/loading.gif" width="20px" id="loader" height="15px"/></button>
                                
                        </div>
                            	</div>
                        	</form>
							</div>
                    	</div>
            	</div>
        	</div>
        	</div>
           <form style="display: none;" name="bankinfo" method="post" action="withdrawal-request-confirm.php">
              <section class="panel">

                <header class="panel-heading">
                  <h3 class="panel-title">Withdrawal Request Form</h3>
                </header>
                <header class="panel-heading">
                 <br> <h3 class="panel-title">e-Wallet Balance :  <strong>0.00</strong> USD<br><br>NOTE : Admin Charge of 4% will be levied for all Withdrawals<br><br>NOTE : Minimum Withdrawal is 50 USD<br><br>Note :  If you have not a valid phone number then you are not able to transfer  <br>
                <br>Note :  0.06 USD will be charge from your account for otp sms.</h3>
                <br></header>
                <div class="panel-body">
            <input name="wallet" id="wallet" tabindex="1" required="" class="" style="width:4%;" value="final_e_wallet" checked="checked" type="hidden">
        `````    
           <div class="form-group">
                      <label for="exampleInputAddress">First Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject1" tabindex="1" value="Stanley " style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>

                      <div class="form-group">
                      <label for="exampleInputAddress">Last Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject2" tabindex="1" value="Paul" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>

                      <div class="form-group">
                      <label for="exampleInputAddress">Account Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject3" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>

  <div class="form-group">
                      <label for="exampleInputAddress">Account Number</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject4" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>


  <div class="form-group">
                      <label for="exampleInputAddress">Bank Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject5" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>


  <div class="form-group">
                      <label for="exampleInputAddress">Branch Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject6" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>



  <div class="form-group">
                      <label for="exampleInputAddress">Swift Code</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject7" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>
<div class="form-group">
                      <label for="exampleInputAddress">Check Your Phone Number Otp Will Be Send</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="phone" required="" value="08135412860" readonly="" class="form-control" type="text">
                      </div>
                     
                    </div>
  <div class="form-group">
                      <label for="exampleInputAddress">Enter Amount</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject8" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="number">
                  
                      </div>
                    </div>


  <div class="form-group">
                      <label for="exampleInputAddress">Description</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="subject9" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="text">
                  
                      </div>
                    </div>

                      <div class="form-group">
                      <label for="exampleInputAddress">Enter Transaction Password</label>
                      <div class="input-group">
                        <span class="input-group-addon"></span>
                        <input name="password" tabindex="1" value="" style="width:100%; border:1px solid #ebebeb; padding:5px;" class="form-control" id="exampleInputAddress" required="" type="password">
                  
                      </div>
                    </div>

   <input name="wallet_from" id="wallet_from" tabindex="1" value="withdrawal" type="hidden">
                <input id="id" name="id" value="247781888636" type="hidden">
                           
                





          <div class="row">
            <div class="col-md-12 animateme scrollme" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">
              <div class="panel">
                <div class="panel-body">
                  <input name="submit" value="Submit" class="btn btn-primary" type="submit">             </div>
              </div>
            </div>
          </div>

              </div></section>

</form>

            </div> <!-- / col-md-6 -->

          

          </div> <!-- / row -->

         

        </div> <!-- / container-fluid -->

    </main>
    </div>
   
    
    </div>
    </div>
    </div>
    
            <footer style="clear:both;" class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="#">
                                Pebles
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               For Uplinks
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Powered by Uplinks. Copyrights 2017. All Rights Reserved.
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with<i class="fa fa-heart heart"></i> by <a href="#">Pebles</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
