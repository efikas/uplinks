<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */
 
 
	include_once 'paypalclass.php';
 
    $credentials['API_USERNAME']  = 'username';
    $credentials['API_PASSWORD']  = 'password';
    $credentials['API_SIGNATURE'] = 'signature';
    $credentials['API_ENDPOINT']  = 'https://api-3t.sandbox.paypal.com/nvp';
 
    $amount  = urlencode($_POST['Amount']);
    $id          = urlencode(123456);
    $note      = urlencode('This is to notify you the withdrawal from your uplinks wallet');
    $subject  = urlencode("Withdrawal From Uplinks");
    $type      = urlencode('EmailAddress');
    $currency = urlencode($_POST['Currency']);
    $customer_email = urlencode($_POST['EmailAddress']);
     
    $base_call  = "&L_EMAIL0=".$customer_email.
                  "&L_AMT0=".$amount.
                  "&L_UNIQUEID0=".$id.
                  "&L_NOTE0=".$note.
                  "&EMAILSUBJECT=".$subject.
                          "&RECEIVERTYPE=".$type.
                          "&CURRENCYCODE=".$currency;
             
    $PayPal = new PayPal_CallerService($credentials);
     
    $status  = $PayPal->callPayPal("MassPay", $base_call);
 
    //Do something if it is successfully sent
    if($status) {
         
        if($status['ACK'] == "Success") {
 
            //Check the balance of the account that was just debited, and make sure we have at least $500 left in our account
            $balance = $PayPal->callPayPal("GetBalance", '');
             
            if($balance['L_AMT0'] < 500) {
                 
                $message = "The balance is low... Please replenish the funds... \n\n".$balance['L_AMT0']." ".$balance['L_CURRENCYCODE0'];
                 
                mail('notifysomeone@routydesign.com','PayPal Refund Balance Low',$message);
                 
            }
             
        } else if($status['ACK'] == "Failure"){
             
            if($status['L_ERRORCODE0'] == '10321') {
                 
                $error = "Insufficient Funds to Send Refund to: ".$_POST['FirstName'].' '.$_POST['LastName'].'('.$_POST['EmailAddress'].') via PayPal in the amount of: '.$_POST['Amount'].' '.$_POST['Currency'].'. ';
                 
            } else if($status['L_ERRORCODE0'] == '10004') {
                 
                $this->view->error = "Invalid Amount of Refund to: ".$_POST['FirstName'].' '.$_POST['LastName'].'('.$_POST['EmailAddress'].') via PayPal in the amount of: '.$_POST['Amount'].' '.$_POST['Currency'].'. Must be more than 0 '.$_POST['Currency'].'.';
                 
            } else {
                 
                $this->view->error = "There was an unknown error when attempting to submit the payment.";
                 
                var_dump($status);
                 
            }
             
        }
         
    }
     

?>