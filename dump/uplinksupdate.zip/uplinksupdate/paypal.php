<input type="text" name="actionType" id="actionType" value="PAY">
<input type="text" name="receiverList.receiver(0).email" id="" value="">
<input type="text" name="receiverList.receiver(0).amount" id="" value="">
<input type="text" name="currencyCode" id="" value="">
<input type="text" name="cancelUrl" id="" value="">
<input type="text" name="returnUrl" id="" value="">

<input type="text" name="requestEnvelope.errorLanguage " id="" value="">

<input type="text" name="senderEmail" id="" value="">

<input type="text" name="sender.accountId " id="" value="">

<input type="text" name="preapprovalKey" id="" value="">

<input type="text" name="pin" id="" value="">
