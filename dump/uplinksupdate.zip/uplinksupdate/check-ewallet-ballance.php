<?php

/**
 * @author Akintola Oluwaseun Je
 * @copyright 2017
 */



?>
<?php include('menu.php'); ?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
	<div id="main">
    <main id="playground">

 
 <div class="container-fluid">
          <div class="row">
       
            <div class="col-md-6 animateme scrollme" style="float:none; margin-left:auto; margin-right:auto;" data-when="enter" data-from="0.2" data-to="0" data-crop="false" data-opacity="0" data-scale="0.5">

           <form name="bankinfo" method="post">
              <section class="panel">

               <?php
               $query=mysqli_query($dbc,"SELECT * FROM user_rank WHERE myid='$myid'");
               $row = mysqli_fetch_array($query);
               $balance =  $row['balance'];    
               ?>
                <header class="panel-heading">
                 <br> <h3 class="panel-title">Ballance in your E-WALLET  :  <strong><?php echo $balance; ?>&nbsp;USD</strong></h3>
                <br></header>
                <div class="panel-body">


              </div></section>

</form>

            </div> <!-- / col-md-6 -->

          

          </div> <!-- / row -->

         

        </div>
    </main>
    </div>
    
    
    </div>
    
    </div>
    </div>
   
            <footer style="clear:both;" class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="#">
                                Pebles
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               For Uplinks
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Powered by Uplinks. Copyrights 2017. All Rights Reserved.
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with<i class="fa fa-heart heart"></i> by <a href="#">Pebles</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
    