<?php

/**
 * @author Akintola Oluwaseun 
 * @copyright 2017
 */

	require_once 'dbconnect.php';
function setvar($var_value, $default = ''){
    
    global $dbc;
if ($var_value != null){
    $set_var = $var_value;
}else{
    $set_var = $default;
}
return $set_var;    
}


function get_fullname($userid){
    
    global $dbc;

    $quer=mysqli_query($dbc, "SELECT * FROM user_table WHERE myid='$userid'");
    $ron = mysqli_fetch_array($quer); 
    $user_name= $ron['firstName'].' '.$ron['lastName'];    
    return $user_name;
    
    }

function checkdesc_stage1($desc1,$desc2,$desc3,$desc4,$desc5,$desc6, $stage_tocheck){
    
    global $dbc;
    
$desc = array($desc1, $desc2,$desc3, $desc4,$desc5, $desc6);

    $count = 0;
    while($count < 2){
        $des = $desc[$count];
    $check_query = "SELECT * FROM `user_rank` WHERE `myid` = '$des'";
  //  echo $check_query;

    $row2 = mysqli_query($dbc, $check_query);
    $row2 = mysqli_fetch_array($row2);
    if($row2[stage] == $stage_tocheck){
        $val = 1;
    } else{
        $val = 0;
    }
    
    if ($val == 0){   
    return $val; 
    }
    
    $count = $count +1;
    
    }
    
    return $val;    
}

function checkdesc_stage2($desc1,$desc2,$desc3,$desc4,$desc5,$desc6, $stage_tocheck){
    
    global $dbc;
    
$desc = array($desc1, $desc2,$desc3, $desc4,$desc5, $desc6);

    $count = 0;
    while($count < 6){
    $check_query = "SELECT * FROM `user_rank` WHERE `myid` = '$desc[$count]'";
    $row = mysqli_query($dbc, $check_query);
    $row = mysqli_fetch_array($row);
    if($row[stage] == $stage_tocheck){
        $val = 1;
    } else{
        $val = 0;
    }
    if ($val == 0){   
    return $val; 
    }
    
    $count = $count +1;
    
    }
    
    return $val;    
}

function checkdesc_stage3($desc1,$desc2,$desc3,$desc4,$desc5,$desc6, $stage_tocheck){
    
    global $dbc;
    
$desc = array($desc1, $desc2,$desc3, $desc4,$desc5, $desc6);

    $count = 0;
    while($count < 2){

    
    $check_query = "SELECT * FROM `user_rank` WHERE `myid` = '$desc[$count]'";
    $row = mysqli_query($dbc, $check_query);
    $row = mysqli_fetch_array($row);
    $sub_desc1 = $row[desc_1];
    $sub_desc2 = $row[desc_2];
    $sub_desc3 = $row[desc_3];
    $sub_desc4 = $row[desc_4];
    $sub_desc5 = $row[desc_5];
    $sub_desc6 = $row[desc_6];
    
    if($row[stage] == $stage_tocheck){
        $val = 1;
    } else{
        $val = 0;
    }
   if ($val == 0){   
    return $val; 
    }
       
    $val = checkdesc_stage2($sub_desc1,$sub_desc2,$sub_desc3,$sub_desc4,$sub_desc5,$sub_desc6,$stage_tocheck);
    
    if ($val == 0){   
    return $val; 
    }
    
    $count = $count +1;
    }
    
    return $val;    
}

function checkdesc_stage4($desc1,$desc2,$desc3,$desc4,$desc5,$desc6, $stage_tocheck){
    
    global $dbc;
    
$desc = array($desc1, $desc2,$desc3, $desc4,$desc5, $desc6);

    $count = 0;
    while($count < 6){

    
    $check_query = "SELECT * FROM `user_rank` WHERE `myid` = '$desc[$count]'";
    $row = mysqli_query($dbc, $check_query);
    $row = mysqli_fetch_array($row);
    $sub_desc1 = $row[desc_1];
    $sub_desc2 = $row[desc_2];
    $sub_desc3 = $row[desc_3];
    $sub_desc4 = $row[desc_4];
    $sub_desc5 = $row[desc_5];
    $sub_desc6 = $row[desc_6];
    
    if($row[stage] == $stage_tocheck){
        $val = 1;
    } else{
        $val = 0;
    }
      if ($val == 0){   
    return $val; 
    }
    
    $val = checkdesc_stage2($sub_desc1,$sub_desc2,$sub_desc3,$sub_desc4,$sub_desc5,$sub_desc6,$stage_tocheck);
    
    if ($val == 0){   
    return $val; 
    }
    
    $count = $count +1;
    }
    
    return $val;    
}
function checkdesc_stage5($desc1,$desc2,$desc3,$desc4,$desc5,$desc6, $stage_tocheck){
    
    global $dbc;
    
$desc = array($desc1, $desc2,$desc3, $desc4,$desc5, $desc6);

    $count = 0;
    while($count < 6){

    
    $check_query = "SELECT * FROM `user_rank` WHERE `myid` = '$desc[$count]'";
    $row = mysqli_query($dbc, $check_query);
    $row = mysqli_fetch_array($row);
    $sub_desc1 = $row[desc_1];
    $sub_desc2 = $row[desc_2];
    $sub_desc3 = $row[desc_3];
    $sub_desc4 = $row[desc_4];
    $sub_desc5 = $row[desc_5];
    $sub_desc6 = $row[desc_6];
    
    if($row[stage] == $stage_tocheck){
        $val = 1;
    } else{
        $val = 0;
    }
      if ($val == 0){   
    return $val; 
    }
    
    $val = checkdesc_stage3($sub_desc1,$sub_desc2,$sub_desc3,$sub_desc4,$sub_desc5,$sub_desc6,$stage_tocheck);
    
    if ($val == 0){   
    return $val; 
    }
    
    $count = $count +1;
    }
    
    return $val;    
}

?>